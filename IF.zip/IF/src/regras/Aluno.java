package regras;

import java.util.Date;

public class Aluno{
    String cpfAluno;
    String nomeAluno;
    Date dataNascimento;
   long idAluno;
    
   public Aluno() {
   }

   public Aluno(String cpfAluno, String nomeAluno, Date dataNascimento) {
      this.cpfAluno = cpfAluno;
      this.nomeAluno = nomeAluno;
      this.dataNascimento = dataNascimento;
   }

   public String getCpfAluno() {
      return cpfAluno;
   }

   public void setCpfAluno(String cpfAluno) {
      this.cpfAluno = cpfAluno;
   }

   public String getNomeAluno() {
      return nomeAluno;
   }

   public void setNomeAluno(String nomeAluno) {
      this.nomeAluno = nomeAluno;
   }

   public Date getDataNascimento() {
      return dataNascimento;
   }

   public void setDataNascimento(Date dataNascimento) {
      this.dataNascimento = dataNascimento;
   }

   public long getIdAluno() {
      return idAluno;
   }

   public void setIdAluno(long idAluno) {
      this.idAluno = idAluno;
   }
    
    
}
