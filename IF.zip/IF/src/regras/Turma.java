package regras;

import java.util.Date;

public class Turma {
   long idTurma;
   String nomeTurma;
   boolean semestreTurma;
   Date anoInicio;

   public Turma() {
   }

   public Turma(String nomeTurma, boolean semestreTurma, Date anoInicio) {
      this.nomeTurma = nomeTurma;
      this.semestreTurma = semestreTurma;
      this.anoInicio = anoInicio;
   }

   public long getIdTurma() {
      return idTurma;
   }

   public void setIdTurma(long idTurma) {
      this.idTurma = idTurma;
   }

   public String getNomeTurma() {
      return nomeTurma;
   }

   public void setNomeTurma(String nomeTurma) {
      this.nomeTurma = nomeTurma;
   }

   public boolean isSemestreTurma() {
      return semestreTurma;
   }

   public void setSemestreTurma(boolean semestreTurma) {
      this.semestreTurma = semestreTurma;
   }

   public Date getAnoInicio() {
      return anoInicio;
   }

   public void setAnoInicio(Date anoInicio) {
      this.anoInicio = anoInicio;
   }
   
   
}
