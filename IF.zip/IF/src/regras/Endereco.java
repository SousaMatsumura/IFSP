package regras;
public class Endereco{
    long idEndereco;
    String rua;
    int numero;
    String cep;

   public Endereco(String rua, int numero, String cep) {
      this.rua = rua;
      this.numero = numero;
      this.cep = cep;
   }

   public Endereco() {
   }
    
   public long getIdEndereco() {
      return idEndereco;
   }

   public void setIdEndereco(long idEndereco) {
      this.idEndereco = idEndereco;
   }

   public String getRua() {
      return rua;
   }

   public void setRua(String rua) {
      this.rua = rua;
   }

   public int getNumero() {
      return numero;
   }

   public void setNumero(int numero) {
      this.numero = numero;
   }

   public String getCep() {
      return cep;
   }

   public void setCep(String cep) {
      this.cep = cep;
   }
}
