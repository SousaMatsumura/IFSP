package regras;
public class CursoDisciplina {
   long idCurso;
   long idDisciplina;
   long idTurma;

   public CursoDisciplina() {
   }

   public long getIdCurso() {
      return idCurso;
   }

   public void setIdCurso(long idCurso) {
      this.idCurso = idCurso;
   }

   public long getIdDisciplina() {
      return idDisciplina;
   }

   public void setIdDisciplina(long idDisciplina) {
      this.idDisciplina = idDisciplina;
   }

   public long getIdTurma() {
      return idTurma;
   }

   public void setIdTurma(long idTurma) {
      this.idTurma = idTurma;
   }
}
