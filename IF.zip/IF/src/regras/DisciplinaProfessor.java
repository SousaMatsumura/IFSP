package regras;
public class DisciplinaProfessor {
   long idDisciplina;
   long idTurma;
   long idProfessor;

   public DisciplinaProfessor() {
   }

   public long getIdDisciplina() {
      return idDisciplina;
   }

   public void setIdDisciplina(long idDisciplina) {
      this.idDisciplina = idDisciplina;
   }

   public long getIdTurma() {
      return idTurma;
   }

   public void setIdTurma(long idTurma) {
      this.idTurma = idTurma;
   }

   public long getIdProfessor() {
      return idProfessor;
   }

   public void setIdProfessor(long idProfessor) {
      this.idProfessor = idProfessor;
   }
   
   
}
