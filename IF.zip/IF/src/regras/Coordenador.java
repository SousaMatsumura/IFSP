package regras;
public class Coordenador {
   long idCoordenador; long idCurso; long idProfessor;

   public Coordenador() {
   }

   public long getIdCoordenador() {
      return idCoordenador;
   }

   public void setIdCoordenador(long idCoordenador) {
      this.idCoordenador = idCoordenador;
   }

   public long getIdCurso() {
      return idCurso;
   }

   public void setIdCurso(long idCurso) {
      this.idCurso = idCurso;
   }

   public long getIdProfessor() {
      return idProfessor;
   }

   public void setIdProfessor(long idProfessor) {
      this.idProfessor = idProfessor;
   }
}
