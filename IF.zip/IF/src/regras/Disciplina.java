package regras;
public class Disciplina {
    long idDisciplina;
    long idTurma;
    String nomeDisciplina;

   public long getIdDisciplina() {
      return idDisciplina;
   }

   public Disciplina() {
   }

   public Disciplina(String nomeDisciplina) {
      this.nomeDisciplina = nomeDisciplina;
   }

   public void setIdDisciplina(long idDisciplina) {
      this.idDisciplina = idDisciplina;
   }

   public long getIdTurma() {
      return idTurma;
   }

   public void setIdTurma(long idTurma) {
      this.idTurma = idTurma;
   }

   public String getNomeDisciplina() {
      return nomeDisciplina;
   }

   public void setNomeDisciplina(String nomeDisciplina) {
      this.nomeDisciplina = nomeDisciplina;
   }
    
}
