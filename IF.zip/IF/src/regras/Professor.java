package regras;
public class Professor {
   long idProfessor;
   String nomeProfessor;
   String cpfProfessor;
   String areaConhecimento;
   String titulos;

   public Professor() {
   }

   public Professor(String nomeProfessor, String cpfProfessor, String areaConhecimento, String titulos) {
      this.nomeProfessor = nomeProfessor;
      this.cpfProfessor = cpfProfessor;
      this.areaConhecimento = areaConhecimento;
      this.titulos = titulos;
   }

   public long getIdProfessor() {
      return idProfessor;
   }

   public void setIdProfessor(long idProfessor) {
      this.idProfessor = idProfessor;
   }

   public String getNomeProfessor() {
      return nomeProfessor;
   }

   public void setNomeProfessor(String nomeProfessor) {
      this.nomeProfessor = nomeProfessor;
   }

   public String getCpfProfessor() {
      return cpfProfessor;
   }

   public void setCpfProfessor(String cpfProfessor) {
      this.cpfProfessor = cpfProfessor;
   }

   public String getAreaConhecimento() {
      return areaConhecimento;
   }

   public void setAreaConhecimento(String areaConhecimento) {
      this.areaConhecimento = areaConhecimento;
   }

   public String getTitulos() {
      return titulos;
   }

   public void setTitulos(String titulos) {
      this.titulos = titulos;
   }
   
   
}
