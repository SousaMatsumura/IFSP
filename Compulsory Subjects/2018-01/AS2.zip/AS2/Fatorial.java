import java.util.Scanner;

public class Fatorial{

   public static void main(String[] args){
      Scanner in = new Scanner(System.in);
      int fat = 1;
      System.out.println("Digite um numero: ");
      int n = in.nextInt();
      if(n>1){
         for(int i = 2; i<=n; i++){
            fat *= i;
         }
      }
      System.out.println("A fatorial �: "+fat);
   }
}