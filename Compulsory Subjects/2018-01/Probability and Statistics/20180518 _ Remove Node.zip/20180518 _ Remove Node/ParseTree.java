import java.io.IOException;
import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;

public class ParseTree{
   static Node root = null;

   public static void main(String[] args){
      readFile("C://Users//a1704443//Downloads//20180511 _ �rvores Bin�rias - Atividade 01//20180511 _ �rvores Bin�rias - Atividade 01//Dados//9.txt");
      print(root);
      System.out.println("Depth: "+depth(root));
      removeNode(root, 6);
   }
    
   public static void removeNode(Node temp, int value){
      if(temp != null){
         switch(removeOption(temp, value)){
            case 0: System.out.println("There isn't a tree...");
            break;
            case 1: removeLeaf(temp, value);
            break;
            case 2: removeNodeWithOneSon(temp, value);
            break;
            case 3: removeNodeWithTwoSon(temp, value);
            break;
            default: System.err.println("ERROR: Impossible condition.");
         }
      }
   }

   public static int removeOption(Node temp, int value){
      if(temp != null){
         if(temp.value == value){
            if(temp.left == null && temp.right == null){
               return 1;
            }else{
               if(temp.left != null && temp.right != null){
                  return 3;
               }
               return 2;
            }
         }else{
            removeOption(temp.left, value);
            removeOption(temp.right, value);
         }
      }
      return 0;
   }
   
   public static void removeLeaf(Node temp, int value){
      
   }

   public static void removeNodeWithOneSon(Node temp, int value){
      
   }
   
   public static void removeNodeWithTwoSon(Node temp, int value){
      
   }


   public static void add(int v){
      Node n = new Node(v);
        
      if(root == null){
         root = n;
      }else{
         boolean add = false;
         Node temp = root;
           
         while(!add){
            if(n.value <= temp.value){
               if(temp.left == null){
                  temp.left = n;
                  add = true;
               }else{
                  temp = temp.left;
               }
            }else{
               if(temp.right == null){
                  temp.right = n;
                  add = true;
               }else{
                  temp = temp.right;
               }
            }
         }
      }
   }
      
   static int depth(Node temp){
      if(temp == null){
         return -1;
      }
      if(temp.left == null && temp.right == null){
         return 0;
      }else{
         if(temp.left != null && temp.right != null){
            if(depth(temp.left)<depth(temp.right)){
               return 1+depth(temp.right);
            }else{
               return 1+depth(temp.left);
            }
         }else{
            if(temp.left != null){
               return 1+depth(temp.left);
            }else{
               return 1+depth(temp.right);
            }
         }
      }
   }
   
   static void readFile(String file){
      try(BufferedReader br = new BufferedReader(new FileReader(new File(file)))){
         String line = br.readLine();
         while(line != null){
            add(Integer.parseInt(line));
            line = br.readLine();
         }
         br.close();
      }catch(IOException e){
         System.err.println("IOException: "+e.getMessage()+"\n"+new File(file).getAbsolutePath());
      }
   }

    
   static void print(Node temp){
      if(temp != null){
         System.out.println(temp.value);
         print(temp.left);
         print(temp.right);
      }
   }
}
