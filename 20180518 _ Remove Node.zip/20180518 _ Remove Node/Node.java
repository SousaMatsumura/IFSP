public class Node{
    int value;
    Node right, left;
    
    Node(int v){
        this.value = v;
        this.right = null;
        this.left = null;
    }
    
}